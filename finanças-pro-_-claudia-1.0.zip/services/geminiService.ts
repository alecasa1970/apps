import { GoogleGenAI, Type } from "@google/genai";
import { Category, Transaction } from "../types";

// Helper to get current date for context
const getCurrentDate = () => new Date().toISOString().split('T')[0];

export interface ParsedAction {
  action: 'create_transaction' | 'create_category' | 'export_data' | 'answer_query' | 'unknown';
  transactionData?: {
    description: string;
    amount: number;
    type: 'income' | 'expense';
    categoryName: string; // We will map this to ID in the app logic
    date: string;
  };
  categoryData?: {
    name: string;
    iconKey: string;
  };
  textResponse?: string;
}

export const processUserMessage = async (
  message: string,
  categories: Category[],
  transactions: Transaction[]
): Promise<ParsedAction> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const categoryNames = categories.map(c => c.name).join(', ');
  const transactionSummary = transactions.slice(0, 50).map(t => 
    `${t.date}: ${t.description} (${t.type}) - R$${t.amount}`
  ).join('\n');

  const systemPrompt = `
    Você é a Claudia 1.0, uma assistente financeira.
    Hoje é: ${getCurrentDate()}.
    Categorias disponíveis: ${categoryNames}.
    Histórico recente:
    ${transactionSummary}

    Analise a mensagem do usuário e determine a ação.
    
    Regras:
    1. Se o usuário informar um gasto ou ganho, retorne action="create_transaction". Tente combinar o nome da categoria com as existentes. Se não existir, use 'Outros'.
    2. Se o usuário pedir para criar categoria, retorne action="create_category". Escolha um ícone da lista Lucide (ex: Dog, Plane, Gift) que combine.
    3. Se o usuário pedir para exportar dados, retorne action="export_data".
    4. Se for uma pergunta sobre gastos, saldo ou análise, retorne action="answer_query" e forneça a resposta no campo textResponse.
    5. Se não entender, retorne action="unknown".

    Responda EXCLUSIVAMENTE com JSON seguindo o schema.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: message,
      config: {
        systemInstruction: systemPrompt,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING, enum: ['create_transaction', 'create_category', 'export_data', 'answer_query', 'unknown'] },
            transactionData: {
              type: Type.OBJECT,
              properties: {
                description: { type: Type.STRING },
                amount: { type: Type.NUMBER },
                type: { type: Type.STRING, enum: ['income', 'expense'] },
                categoryName: { type: Type.STRING },
                date: { type: Type.STRING }
              },
            },
            categoryData: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                iconKey: { type: Type.STRING }
              }
            },
            textResponse: { type: Type.STRING }
          }
        }
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as ParsedAction;
    }
    throw new Error("Empty response from AI");
  } catch (error) {
    console.error("Gemini Error:", error);
    return { action: 'unknown', textResponse: "Desculpe, tive um erro ao processar sua solicitação. Tente novamente." };
  }
};