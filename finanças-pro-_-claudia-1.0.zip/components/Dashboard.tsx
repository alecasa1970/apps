import React, { useMemo } from 'react';
import { Transaction, Category, TransactionType } from '../types';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { TrendingUp, TrendingDown, DollarSign, PlusCircle, MinusCircle } from 'lucide-react';

interface DashboardProps {
  transactions: Transaction[];
  categories: Category[];
  onOpenTransactionModal: (type: TransactionType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ transactions, categories, onOpenTransactionModal }) => {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const currentMonthTransactions = useMemo(() => {
    return transactions.filter(t => {
      const d = new Date(t.date);
      return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
    });
  }, [transactions, currentMonth, currentYear]);

  const stats = useMemo(() => {
    const income = currentMonthTransactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
    const expense = currentMonthTransactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
    return { income, expense, balance: income - expense };
  }, [currentMonthTransactions]);

  const expenseByCategory = useMemo(() => {
    const data: Record<string, number> = {};
    currentMonthTransactions.filter(t => t.type === 'expense').forEach(t => {
      const cat = categories.find(c => c.id === t.categoryId);
      const name = cat ? cat.name : 'Desconhecido';
      data[name] = (data[name] || 0) + t.amount;
    });
    return Object.entries(data).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [currentMonthTransactions, categories]);

  // Monthly Evolution (Last 6 months)
  const evolutionData = useMemo(() => {
    const data = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(currentMonth - i);
      const monthKey = d.toLocaleString('pt-BR', { month: 'short' });
      
      const monthlyTrans = transactions.filter(t => {
        const tDate = new Date(t.date);
        return tDate.getMonth() === d.getMonth() && tDate.getFullYear() === d.getFullYear();
      });

      const income = monthlyTrans.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0);
      const expense = monthlyTrans.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0);
      
      data.push({ name: monthKey, Receitas: income, Despesas: expense });
    }
    return data;
  }, [transactions, currentMonth]);

  const COLORS_CHART = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Quick Actions */}
      <div className="flex gap-4">
        <button 
          onClick={() => onOpenTransactionModal('income')}
          className="flex-1 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white p-4 rounded-xl shadow-md shadow-emerald-100 hover:shadow-lg hover:from-emerald-600 hover:to-emerald-700 transition-all flex items-center justify-center gap-2 group"
        >
          <PlusCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
          <span className="font-semibold">Nova Receita</span>
        </button>
        <button 
          onClick={() => onOpenTransactionModal('expense')}
          className="flex-1 bg-gradient-to-r from-rose-500 to-rose-600 text-white p-4 rounded-xl shadow-md shadow-rose-100 hover:shadow-lg hover:from-rose-600 hover:to-rose-700 transition-all flex items-center justify-center gap-2 group"
        >
          <MinusCircle className="w-6 h-6 group-hover:scale-110 transition-transform" />
          <span className="font-semibold">Nova Despesa</span>
        </button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Saldo Atual</p>
              <h3 className={`text-2xl font-bold ${stats.balance >= 0 ? 'text-slate-800' : 'text-red-500'}`}>
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.balance)}
              </h3>
            </div>
            <div className="p-3 bg-indigo-50 rounded-full">
              <DollarSign className="w-6 h-6 text-indigo-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Receitas (Mês)</p>
              <h3 className="text-2xl font-bold text-emerald-600">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.income)}
              </h3>
            </div>
            <div className="p-3 bg-emerald-50 rounded-full">
              <TrendingUp className="w-6 h-6 text-emerald-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-slate-500 mb-1">Despesas (Mês)</p>
              <h3 className="text-2xl font-bold text-rose-600">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(stats.expense)}
              </h3>
            </div>
            <div className="p-3 bg-rose-50 rounded-full">
              <TrendingDown className="w-6 h-6 text-rose-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Expense Distribution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96 flex flex-col">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Distribuição de Despesas</h3>
          {expenseByCategory.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={expenseByCategory}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {expenseByCategory.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS_CHART[index % COLORS_CHART.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-400">
              Sem despesas este mês.
            </div>
          )}
        </div>

        {/* Monthly Evolution */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-100 h-96 flex flex-col">
          <h3 className="text-lg font-semibold text-slate-800 mb-4">Evolução Financeira</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={evolutionData}>
              <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `R$${val}`} />
              <Tooltip 
                formatter={(value: number) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value)}
                cursor={{ fill: '#f8fafc' }}
              />
              <Legend iconType="circle" />
              <Bar dataKey="Receitas" fill="#10b981" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Despesas" fill="#f43f5e" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;