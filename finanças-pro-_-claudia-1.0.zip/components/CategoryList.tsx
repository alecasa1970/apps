import React, { useState } from 'react';
import { Category, TransactionType } from '../types';
import { ICON_MAP, AVAILABLE_ICONS, COLORS } from '../constants';
import { Trash2, Plus, X, Tag } from 'lucide-react';

interface CategoryListProps {
  categories: Category[];
  onDelete: (id: string) => void;
  onCreate: (data: { name: string; iconKey: string; color: string; type: TransactionType }) => void;
}

const CategoryList: React.FC<CategoryListProps> = ({ categories, onDelete, onCreate }) => {
  const [isCreating, setIsCreating] = useState(false);
  const [newCatName, setNewCatName] = useState('');
  const [newCatType, setNewCatType] = useState<TransactionType>('expense');
  const [newCatIcon, setNewCatIcon] = useState('ShoppingBag');
  const [newCatColor, setNewCatColor] = useState(COLORS[0]);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatName) return;
    
    onCreate({
      name: newCatName,
      iconKey: newCatIcon,
      color: newCatColor,
      type: newCatType
    });
    
    setIsCreating(false);
    setNewCatName('');
    setNewCatIcon('ShoppingBag');
  };

  const renderCategorySection = (type: TransactionType, title: string) => (
    <div className="mb-8">
      <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center gap-2">
        {type === 'income' ? <div className="w-2 h-2 rounded-full bg-emerald-500" /> : <div className="w-2 h-2 rounded-full bg-rose-500" />}
        {title}
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {categories.filter(c => c.type === type).map((cat) => {
          const Icon = ICON_MAP[cat.iconKey] || ICON_MAP['MoreHorizontal'];
          return (
            <div key={cat.id} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex items-center justify-between group hover:border-indigo-100 transition-all">
              <div className="flex items-center gap-3">
                <div 
                  className="w-10 h-10 rounded-full flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${cat.color}20`, color: cat.color }}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="font-medium text-slate-700 truncate">{cat.name}</span>
              </div>
              {!cat.isDefault && (
                <button 
                  onClick={() => onDelete(cat.id)}
                  className="text-slate-300 hover:text-red-500 p-2 rounded-full hover:bg-red-50 transition-colors"
                  title="Excluir categoria"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );

  return (
    <div className="space-y-6 pb-20">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Categorias</h2>
          <p className="text-slate-500 text-sm">Gerencie suas categorias de receitas e despesas</p>
        </div>
        <button 
          onClick={() => setIsCreating(true)}
          className="bg-indigo-600 text-white px-4 py-2 rounded-lg shadow-md shadow-indigo-200 hover:bg-indigo-700 transition-colors flex items-center gap-2"
        >
          <Plus className="w-4 h-4" /> Nova Categoria
        </button>
      </div>

      {isCreating && (
        <div className="bg-white p-6 rounded-xl border border-indigo-100 shadow-lg animate-fade-in mb-8">
          <div className="flex justify-between items-start mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Criar Nova Categoria</h3>
            <button onClick={() => setIsCreating(false)} className="text-slate-400 hover:text-slate-600">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          <form onSubmit={handleCreate} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Basic Info */}
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Nome da Categoria</label>
                  <input
                    type="text"
                    required
                    value={newCatName}
                    onChange={(e) => setNewCatName(e.target.value)}
                    className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    placeholder="Ex: Assinaturas, Pets..."
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-1">Tipo</label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="type" 
                        checked={newCatType === 'expense'} 
                        onChange={() => setNewCatType('expense')}
                        className="text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-slate-700">Despesa</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="radio" 
                        name="type" 
                        checked={newCatType === 'income'} 
                        onChange={() => setNewCatType('income')}
                        className="text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="text-sm text-slate-700">Receita</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-500 mb-2">Cor</label>
                  <div className="flex flex-wrap gap-2">
                    {COLORS.map(color => (
                      <button
                        key={color}
                        type="button"
                        onClick={() => setNewCatColor(color)}
                        className={`w-6 h-6 rounded-full transition-transform hover:scale-110 ${newCatColor === color ? 'ring-2 ring-offset-1 ring-slate-400 scale-110' : ''}`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              {/* Icon Selection */}
              <div>
                <label className="block text-xs font-medium text-slate-500 mb-2">Ícone</label>
                <div className="grid grid-cols-6 gap-2 max-h-48 overflow-y-auto p-2 bg-slate-50 rounded-lg border border-slate-200">
                  {AVAILABLE_ICONS.map(iconKey => {
                    const Icon = ICON_MAP[iconKey];
                    return (
                      <button
                        key={iconKey}
                        type="button"
                        onClick={() => setNewCatIcon(iconKey)}
                        className={`p-2 rounded-lg flex items-center justify-center transition-colors ${newCatIcon === iconKey ? 'bg-indigo-100 text-indigo-600 ring-1 ring-indigo-500' : 'text-slate-500 hover:bg-white hover:shadow-sm'}`}
                      >
                        <Icon className="w-5 h-5" />
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
              <button 
                type="button" 
                onClick={() => setIsCreating(false)}
                className="px-4 py-2 text-slate-600 hover:bg-slate-100 rounded-lg text-sm font-medium"
              >
                Cancelar
              </button>
              <button 
                type="submit"
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 shadow-md shadow-indigo-200"
              >
                Criar Categoria
              </button>
            </div>
          </form>
        </div>
      )}

      {renderCategorySection('expense', 'Categorias de Despesas')}
      {renderCategorySection('income', 'Categorias de Receitas')}
    </div>
  );
};

export default CategoryList;